require("dotenv").config();

const { PORT: port } = process.env;

module.exports = { port };
